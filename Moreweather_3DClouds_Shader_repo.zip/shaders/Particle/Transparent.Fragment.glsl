#version 310 es

/*
* Available Macros:
*
* Passes:
* - ALPHA_TEST_PASS (not used)
* - TRANSPARENT_PASS (not used)
*
* Instancing:
* - INSTANCING__OFF (not used)
* - INSTANCING__ON (not used)
*
* Available Resources:
*
* Buffers:
* - uniform lowp sampler2D s_ParticleTexture;
*
* Uniforms:
* - uniform vec4 FogAndDistanceControl;
* - uniform vec4 FogColor;
* - uniform vec4 LightDiffuseColorAndIlluminance;
* - uniform vec4 LightWorldSpaceDirection;
*/

precision mediump float;
precision highp int;
uniform highp sampler2D s_ParticleTexture;
in highp vec4 v_color0;
in highp vec4 v_fog;
in highp vec2 v_texcoord0;
in highp vec3 v_worldPos;
in highp vec3 v_center;
in highp vec3 v_cam;
in highp vec2 v_params;
uniform highp vec4 LightWorldSpaceDirection;
layout(location = 0) out highp vec4 bgfx_FragData0;

// ---- 3D Clouds (Moreweather): raymarching de nuvem dentro de um elipsoide ------------------------------------------------
#define RM_STEPS 22            // passos de visão  (celular: 16-24)
#define RM_LIGHT_STEPS 3       // passos de sombra (celular: 2-4)
#define RM_FOG_AMOUNT 0.55     // quanto da névoa do jogo vale pra nuvem (0 = nenhuma, 1 = igual às outras partículas)

highp float rm_hash(highp vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
highp float rm_noise(highp vec3 x) {
    highp vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(rm_hash(i), rm_hash(i + vec3(1,0,0)), f.x), mix(rm_hash(i + vec3(0,1,0)), rm_hash(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(rm_hash(i + vec3(0,0,1)), rm_hash(i + vec3(1,0,1)), f.x), mix(rm_hash(i + vec3(0,1,1)), rm_hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}
highp float rm_fbm(highp vec3 p, int oct) {
    highp float a = 0.5, s = 0.0;
    for (int i = 0; i < oct; i++) { s += a * rm_noise(p); p = p * 2.03 + 11.7; a *= 0.5; }
    return s;
}
// densidade no ponto q (coordenadas normalizadas do elipsoide, |q| <= 1): borda suave esculpida por ruído (ancorada no centro da nuvem, não na câmera)
highp float rm_density(highp vec3 q, int oct) {
    highp float edge = 1.0 - dot(q, q);
    if (edge <= 0.0) return 0.0;
    highp float n = rm_fbm(q * 3.2 + vec3(v_params.y * 7.0, 0.0, 0.0), oct);
    return clamp((edge * 1.6 + n - 0.78) * 2.2, 0.0, 1.0);
}
bool rm_is_cloud() {
    // "selo": a textura rm_fallback.png tem o texel (0,0) com alfa = 2/255. As outras partículas do jogo nunca têm isso.
    highp float a = texelFetch(s_ParticleTexture, ivec2(0, 0), 0).a;
    return abs(a - 2.0 / 255.0) < 0.5 / 255.0;
}
highp vec4 rm_cloud() {
    highp vec3 radii = vec3(v_params.x, v_params.x * v_params.y, v_params.x);
    highp vec3 d = normalize(v_worldPos - v_cam);
    highp vec3 o = (v_cam - v_center) / radii;           // origem do raio no espaço do elipsoide
    highp vec3 dn = d / radii;
    highp float A = dot(dn, dn), B = dot(o, dn), C = dot(o, o) - 1.0;
    highp float disc = B * B - A * C;
    if (disc <= 0.0) discard;
    highp float sq = sqrt(disc);
    highp float t0 = max((-B - sq) / A, 0.0), t1 = (-B + sq) / A;
    if (t1 <= t0) discard;
    highp float dt = (t1 - t0) / float(RM_STEPS);

    highp vec3 sun = LightWorldSpaceDirection.xyz;
    if (dot(sun, sun) < 0.01) sun = vec3(0.35, 0.8, 0.25);   // uniforme vazio: sol fixo
    sun = normalize(sun);
    if (sun.y < 0.0) sun = -sun;                              // garante que a "luz" vem de cima
    highp vec3 sunN = sun / radii;

    highp float jitter = rm_hash(vec3(gl_FragCoord.xy, 7.0));
    highp float trans = 1.0;
    highp vec3 col = vec3(0.0);
    for (int i = 0; i < RM_STEPS; i++) {
        highp float t = t0 + (float(i) + jitter) * dt;
        highp vec3 q = o + dn * t;                            // = (ponto - centro) / raios
        highp float dens = rm_density(q, 3);
        if (dens > 0.01) {
            highp float shadow = 0.0;
            for (int j = 1; j <= RM_LIGHT_STEPS; j++) shadow += rm_density(q + sunN * (float(j) * 0.28), 2);
            highp float light = exp(-shadow * 1.3);
            highp float powder = 1.0 - exp(-dens * 3.0);
            highp vec3 lit = v_color0.rgb * (0.40 + 1.0 * light * (0.6 + 0.4 * powder));
            highp float a = 1.0 - exp(-dens * dt * 5.0);
            col += trans * a * lit;
            trans *= (1.0 - a);
            if (trans < 0.03) break;
        }
    }
    highp float alpha = 1.0 - trans;
    highp vec3 rgb = col / max(alpha, 0.0001);                // blend do material é SRC_ALPHA, ONE_MINUS_SRC_ALPHA (não premultiplicado)
    rgb = mix(rgb, v_fog.xyz, v_fog.w * RM_FOG_AMOUNT);
    return vec4(rgb, alpha * v_color0.w);
}
void main() {
    if (rm_is_cloud()) {
        bgfx_FragData0 = rm_cloud();
        return;
    }

    highp vec4 var_e966b = v_color0;
    highp vec4 var_6ca24 = v_fog;
    highp vec4 var_de643 = texture(s_ParticleTexture, v_texcoord0) * vec4(v_color0.xyz, var_e966b.w);
    highp vec3 var_97f02 = mix(var_de643.xyz, v_fog.xyz, vec3(var_6ca24.w));
    highp vec4 var_1146b = vec4(var_97f02.x, var_97f02.y, var_97f02.z, var_de643.w);
    highp vec4 var_eb888 = v_fog;
    bgfx_FragData0 = vec4(mix(vec4(var_97f02, var_1146b.w).xyz, v_fog.xyz, vec3(var_eb888.w)), var_1146b.w);
}
