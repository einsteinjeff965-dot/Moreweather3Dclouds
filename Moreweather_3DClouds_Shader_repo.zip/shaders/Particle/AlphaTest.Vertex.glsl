#version 310 es

/*
* Available Macros:
*
* Passes:
* - ALPHA_TEST_PASS (not used)
* - TRANSPARENT_PASS (not used)
*
* Instancing:
* - INSTANCING__OFF
* - INSTANCING__ON
*
* Available Resources:
*
* Buffers:
* - uniform lowp sampler2D s_ParticleTexture;
*
* Uniforms:
* - uniform vec4 FogAndDistanceControl;
* - uniform vec4 FogColor;
* - uniform vec4 LightDiffuseColorAndIlluminance;
* - uniform vec4 LightWorldSpaceDirection;
*/

#ifdef INSTANCING__OFF
uniform mat4 u_model[4];
#endif
uniform mat4 u_viewProj;
uniform vec4 FogAndDistanceControl;
uniform vec4 FogColor;
in vec4 a_color0;
in vec3 a_position;
in vec2 a_texcoord0;
#ifdef INSTANCING__ON
in vec4 i_data1;
in vec4 i_data2;
in vec4 i_data3;
#endif
out vec4 v_color0;
out vec4 v_fog;
out vec2 v_texcoord0;
out vec3 v_worldPos;
// ---- 3D Clouds (Moreweather) -------------------------------------------------------------------------------------------
// Só usado pelas partículas weather:rm_cloud (o fragment decide pelo "selo" na textura). Nas outras partículas estes valores são ignorados.
out vec3 v_center;   // centro do elipsoide de nuvem (mesmo espaço de v_worldPos)
out vec3 v_cam;      // posição da câmera nesse espaço (resolvida a partir de u_viewProj, sem supor camera-relative)
out vec2 v_params;   // x = raio (blocos), y = achatamento vertical (meia-altura / raio)
const float RM_RADIUS[8] = float[8](300.0, 500.0, 750.0, 1000.0, 1400.0, 1900.0, 2600.0, 3500.0); // = RADIUS_TABLE em raymarch_clouds.js
const float RM_FLAT[8]   = float[8](0.15, 0.25, 0.35, 0.5, 0.65, 0.8, 0.9, 1.0);                   // = FLAT_TABLE
#define RM_FLIP_Y 1.0   // se a nuvem aparecer de cabeça pra baixo / deslocada na vertical, troque para -1.0
#define RM_FLIP_X 1.0   // idem na horizontal
void main() {
#ifdef INSTANCING__OFF
    vec4 var_12727 = u_model[0] * vec4(a_position, 1.0);
#endif
#ifdef INSTANCING__ON
    vec4 var_78b44 = i_data1;
    vec4 var_e67a8 = i_data2;
    vec4 var_1b7f0 = i_data3;
    mat4 var_e43a8;
    var_e43a8[0] = vec4(var_78b44.x, var_e67a8.x, var_1b7f0.x, 0.0);
    var_e43a8[1] = vec4(var_78b44.y, var_e67a8.y, var_1b7f0.y, 0.0);
    var_e43a8[2] = vec4(var_78b44.z, var_e67a8.z, var_1b7f0.z, 0.0);
    var_e43a8[3] = vec4(var_78b44.w, var_e67a8.w, var_1b7f0.w, 1.0);
    vec4 var_12727 = var_e43a8 * vec4(a_position, 1.0);
#endif
    vec4 var_32522 = u_viewProj * vec4(var_12727.xyz, 1.0);
    vec4 var_b4024 = var_32522;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp(((var_b4024.z / FogAndDistanceControl.z) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_texcoord0 = a_texcoord0;
    v_worldPos = var_12727.xyz;
    {
        // linhas da matriz view*proj: x_clip = dot(r0, p), y_clip = dot(r1, p), w_clip = dot(r3, p)
        vec4 r0 = vec4(u_viewProj[0][0], u_viewProj[1][0], u_viewProj[2][0], u_viewProj[3][0]);
        vec4 r1 = vec4(u_viewProj[0][1], u_viewProj[1][1], u_viewProj[2][1], u_viewProj[3][1]);
        vec4 r3 = vec4(u_viewProj[0][3], u_viewProj[1][3], u_viewProj[2][3], u_viewProj[3][3]);
        vec3 camRight = normalize(r0.xyz) * RM_FLIP_X;
        vec3 camUp    = normalize(r1.xyz) * RM_FLIP_Y;
        // a câmera é o ponto onde x_clip = y_clip = w_clip = 0  ->  A * c = -b
        mat3 A = transpose(mat3(r0.xyz, r1.xyz, r3.xyz));
        v_cam = inverse(A) * (-vec3(r0.w, r1.w, r3.w));
        // o UV do quad guarda a célula do atlas 8x8 (32x32, com 1 px de folga): X = achatamento, Y = raio
        vec2 g = a_texcoord0 * 8.0;
        ivec2 cell = ivec2(clamp(floor(g), vec2(0.0), vec2(7.0)));
        float R = RM_RADIUS[cell.y];
        vec2 t = (fract(g) - 0.03125) / 0.9375;               // 0..1 dentro do quad (canto a canto)
        vec2 o = vec2((t.x - 0.5) * 2.0 * R, (0.5 - t.y) * 2.0 * R);
        v_center = var_12727.xyz - camRight * o.x - camUp * o.y;
        v_params = vec2(R, RM_FLAT[cell.x]);
    }
    gl_Position = var_32522;
}
